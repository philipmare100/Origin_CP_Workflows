# older method self-contained
import json
import logging
import math
from typing import Optional, Dict, List, Tuple

import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
import os

from tqdm import tqdm
from dataclasses import dataclass


class ValidityCheck:
    """
    This class encapsulates the validity checkers. The request or boto3 response is passed in a parameter to the class,
    and the appropriate response validity check method is called.
    """

    def __init__(self, response: requests.Response) -> None:
        self.response = response

    def check_requests_response_validity(self):
        """
        This function checks the validity of a response and raises an exception if it does not have a status code of 200 or 404
        """
        if self.response.status_code in [200, 204]:
            return True
            # Get Message:
        if hasattr(self.response, 'content'):
            msg = json.loads(self.response.content)
        elif hasattr(self.response, 'data'):
            msg = json.loads(self.response.data)
        elif hasattr(self.response, '_content'):
            msg = json.loads(self.response._content)
        elif hasattr(self.response, '_data'):
            msg = json.loads(self.response._data)
        else:
            raise Exception(f'Could not decode response content. Status code: {self.response.status_code}')

        if self.response.status_code == 400:
            raise Exception('Invalid Request', msg)
        elif self.response.status_code == 401:
            raise Exception('Operation not Authorized', msg)
        elif self.response.status_code == 403:
            raise Exception('Authentication failed with the provided token', msg)
        elif self.response.status_code == 500:
            raise Exception('Client-side server error on', msg)
        elif self.response.status_code == 502:
            raise Exception('Could not reach host', msg)
        else:
            raise Exception(f'Got Status {self.response.status_code}: {msg}')


@dataclass
class Series:
    name: str
    id: str
    start_time: str = None
    end_time: str = None

    def __post_init__(self):
        if self.start_time_str:
            self.__set_start_time(self.start_time_str)
        if self.end_time_str:
            self.__set_end_time(self.end_time_str)

    def __set_start_time(self, start_time_str):
        # You can use datetime.strptime to parse the input string
        # and format it as desired.
        # Example input: '2023-09-18T08:00:00.000Z'
        # Example output: '2023-09-18T08:00:00.000Z'
        self.start_time = start_time_str

    def __set_end_time(self, end_time_str):
        # Similar to set_start_time, parse and format the input string.
        self.end_time = end_time_str


class WIRESession:
    """
    A base class to handle the WIRE session. Logs into wire using the credentials provided.
     Generates an auth_obj that can be used for subsequent post and get requests.
    :param
    email -> user email
    password -> user's password. If not provided, the user must provide their security token obtained from 'My security page'
    token -> JWT of user, Not required if password is provided
    client_domain -> url of the client domain for example: htpps://kamoa.mmswire.com
    """

    def __init__(self, email: str, password: str, client_domain: str, verify_ssl: bool = True) -> None:
        # Private attributes
        self.__email = email
        self.__password = password

        # Auth object to be used during requests to WIRE
        self.auth_obj = HTTPBasicAuth(self.__email, self.__password)
        self.auth_data = json.dumps({'email': self.__email, 'password': self.__password})
        self.verify_ssl = verify_ssl
        # Client_domain and default headers to be used during requests to WIRE
        self.client_domain = client_domain
        self.default_headers = {'Content-Type': 'application/vnd.api+json'}

        # On instantiation the login details are checked
        self.__login()

    def __login(self):
        # Handle session authentication using self._auth_obj
        """Login into WIRE, and store the session and cookies."""

        login_url = self.client_domain + '/auth/login'
        auth_response = requests.post(url=login_url, data=self.auth_data, headers=self.default_headers,
                                      verify=self.verify_ssl)

        # Check the if one was able to login succesfully.
        ValidityCheck(auth_response).check_requests_response_validity()


class RequestHandler:
    def __init__(self, session: WIRESession) -> None:
        self.session = session

    def send_request(self, method: str, endpoint: str, params=None, json_data=None) -> requests.Response:
        url = self.session.client_domain + endpoint
        # Ensure method is uppercase
        method = method.upper()
        if method == 'GET':
            response = requests.get(url, params=params, headers=self.session.default_headers,
                                    auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'POST':
            response = requests.post(url, json=json_data, headers=self.session.default_headers,
                                     auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'PUT':
            response = requests.put(url, json=json_data, headers=self.session.default_headers,
                                    auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'PATCH':
            response = requests.patch(url, json=json_data, headers=self.session.default_headers,
                                      auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'DELETE':
            response = requests.delete(url, headers=self.session.default_headers, auth=self.session.auth_obj,
                                       verify=self.session.verify_ssl)
        else:
            raise ValueError("Unsupported HTTP method")

        return response


class LogManager:
    def __init__(self, log_filename):
        self.filename = log_filename

    def log_failed_requests(self, failed_requests):
        with open(self.filename, 'w') as file:
            file.writelines("\n".join(failed_requests))


class SeriesHandler:

    def __init__(self, series_file_name, request_handler: RequestHandler, wire_session: WIRESession):
        self.__series_file_name: str = series_file_name
        self.__request_handler = request_handler
        self.__wire_session = wire_session
        self.__series_list = self.read_csv_data()
        self.__sucessful = []
        self.__failed = []

    def read_csv_data(self):
        series_list = pd.read_csv(self.__series_file_name)
        return series_list

    def create_series_object(self, row):
        series_obj = Series(name=row['name'], id=row['id'], start_time=row['start_time'], end_time=row['end_time'])
        return series_obj

    def construct_update_calc_url(self, series_obj: Series):
        # Construct the url for the single series and time range it needs updating for
        url = f'{self.__wire_session.client_domain}api/GetCalcs?series_list={series_obj.series_id}&deepness=7&start={series_obj.start_time}&end={series_obj.end_time}&insert_data=true&deep=true&sample_period=hour&run_dependent_calcs=true&override=true'
        return url

    def update_calc(self, url):
        # call the request handler to update the calc
        response = self.__request_handler.send_request('GET', endpoint=url)
        ValidityCheck(response).check_requests_response_validity()
        return response

    def check_successful_update(self, response, series_obj: Series):
        # check if the update was successful, if not add to log file
        if response.statuscode == 200:
            msg = f"Successfully updated the calculation for {series_obj.name}, from {series_obj.start_time} to {series_obj.end_time}"
            logging.info(msg)
            self.__sucessful.append(series_obj)
        else:
            msg = f"There was a problem in updating the calculation for {series_obj.name}, from {series_obj.start_time} to {series_obj.end_time}"
            logging.warning(msg)
            self.__failed.append(msg)

    def main_execute(self):
        series_list = self.read_csv_data()
        for _, row in tqdm(series_list.iterrows(), total=series_list.shape[0]):
            series_obj = self.create_series_object(row)
            url = self.construct_update_calc_url(series_obj)
            response = self.update_calc(url)
            self.check_successful_update(response, series_obj)
        return self.__failed, self.__sucessful


def main():
    # Setup the file path for logging.
    current_directory = os.getcwd()
    failed_log_file_name = "WIRE_SERIES_CALC_UPDATE_FAILED.txt"
    sucess_log_file_name = "WIRE_SERIES_CALC_UPDATE_SUCCESS.txt"
    failed_full_path = os.path.join(current_directory, failed_log_file_name)
    success_full_path = os.path.join(current_directory, sucess_log_file_name)
    failed_log_manager = LogManager(failed_full_path)
    sucessfull_log_manager = LogManager(success_full_path)

    # Asking for the user input.
    use_env = input("Would you like to use the .env file for basic inputs?[y|n]:").lower()
    if use_env == 'y':
        msg = 'Using the .env to load basic inputs...'
        logging.info(msg)
        email = os.getenv('wire_username', None)
        pwd = os.getenv('wire_password', None)
        client_domain = os.getenv('client_domain', None)
        base_folder_path = os.getenv('base_folder_path', None)
        if email is None or pwd is None:
            msg = f'Missing entries in the .env file, please enter them manually'
            logging.info(msg)
            email = input("Please enter email address to be used to upload data to WIRE: ")
            pwd = input("Please enter your password: ")
    elif use_env == 'n':
        email = input("Please enter email address to be used to upload data to WIRE: ")
        pwd = input("Please enter your password: ")
        client_domain = input("Please enter the client domain: ")

    wire_session = WIRESession(email=email, password=pwd, client_domain=client_domain)
    requests_handler = RequestHandler(session=wire_session)
    filepath = input("Please enter the filename of the CSV: ")
    if base_folder_path:
        full_filepath = os.path.join(base_folder_path, filepath)
    else:
        msg = f'No base file path was provided'
        logging.warning(msg)
        full_filepath = input("Please enter the full filepath to the CSV: ")
    series_handler = SeriesHandler(full_filepath, requests_handler, wire_session)
    failed, succesful = series_handler.main_execute()
    failed_log_manager.log_failed_requests(failed)
    sucessfull_log_manager.log_failed_requests(succesful)
    logging.info(
        f'Completed the update of the series calcs, please see the log files for more details on their sucess ({str(sucess_log_file_name)}) or failure ({str(failed_log_file_name)})')


if __name__ == '__main__':
    main()
