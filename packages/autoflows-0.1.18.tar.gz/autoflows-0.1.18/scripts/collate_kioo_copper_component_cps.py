import logging
import os

from coffee.client import JsonApiClient
from coffee.schemas import api_schema_all
from coffee.workflows.collation_workflows import ComponentCollationWorkflow


def get_file_path(file_name, sub_dirname='data'):
    cwd = os.path.dirname(__file__)
    path = os.path.join(cwd, sub_dirname)
    return os.path.join(path, file_name)


def bulk_create_collation_series_export():
    csv_file_path = get_file_path('kioo_copper_collation_series.csv')
    logging.debug(f"Now bulk collating: {csv_file_path} to {os.getenv('API_BASE_URL')}")

    with JsonApiClient(schema=api_schema_all) as client:
        component_collation_workflow = ComponentCollationWorkflow(client)
        component_collation_workflow.bulk_create_collation_series_export(csv_file_path)


if __name__ == '__main__':
    bulk_create_collation_series_export()
