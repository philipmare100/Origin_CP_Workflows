import os
import math
import time
import yaml
import base64
import logging
import warnings

from dotenv import load_dotenv
from dateutil.parser import parse
from datetime import timedelta, datetime
from tqdm import tqdm
import requests

load_dotenv()

logging.basicConfig(filename='process_log.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
warnings.filterwarnings("ignore", message="Unverified HTTPS request")


def save_time_cursor(time_cursor, file_path):
    """Function to save the time cursor to a yaml file"""
    with open(file_path, 'w') as file:
        yaml.dump({'time_cursor': time_cursor.isoformat()}, file)


def load_time_cursor(file_path):
    """Function to load the time cursor from a yaml file"""
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        return parse(data['time_cursor'])


def make_request_with_backoff(url, headers, max_wait=100):
    """Make HTTP GET request with exponential backoff"""
    backoff_time = 1
    while True:
        response = requests.get(url, headers=headers, verify=True)
        if response.status_code == 200:
            return response.json()
        else:
            logging.error(f'Error: {response.status_code} | {response.text}. Retrying in {backoff_time} seconds...')
            time.sleep(backoff_time)
            backoff_time *= 2
            if backoff_time > max_wait:
                logging.error("Max wait time exceeded")
                return None  # Consider how you want to handle total failure scenarios


def execute(username='h',
            time_cursor_path='bulk_import_time_cursor.yaml',
            series_string_fpath='mtk_bulk_import_series_string.txt',
            time_delta_hours=3):
    """Main execution function"""
    api_token = os.getenv('API_TOKEN')
    auth_header = {
        'Authorization': 'Basic ' + base64.b64encode(f"{username}:{api_token}".encode()).decode("ascii"),
        'Content-type': 'application/json'
    }
    base_url = os.getenv(
        'API_BASE_URL') + "/utils/BulkImportOpsData?series_string={series_string}&start={start}&end={end}"

    time_cursor = load_time_cursor(time_cursor_path)
    stop_time = datetime.now()

    series_names = load_series_string(series_string_fpath)

    total_iterations = math.ceil((stop_time - time_cursor) / timedelta(hours=time_delta_hours))
    logging.info(f"=================== Start Process for Time '{time_cursor}' to '{stop_time}' =================")
    logging.info(f'Total Iterations: {total_iterations}')
    progress_bar = tqdm(total=total_iterations, desc="Processing Time")

    while time_cursor < stop_time:
        q_start = time_cursor.isoformat()
        q_end = (time_cursor + timedelta(hours=time_delta_hours)).isoformat()
        for series_name in tqdm(series_names, desc='Series', leave=False):
            formatted_url = base_url.format(series_string=series_name, start=q_start, end=q_end)
            make_request_with_backoff(formatted_url, auth_header)

        time_cursor += timedelta(hours=time_delta_hours)
        save_time_cursor(time_cursor - timedelta(hours=1), time_cursor_path)
        progress_bar.update(1)

    progress_bar.close()
    logging.info("Process Completed Successfully")
    logging.info(
        f"====================== End Process for Time '{time_cursor}' to '{stop_time}' =====================")


def load_series_string(filename) -> list[str]:
    with open(filename, 'r') as file:
        data = file.read()
    return data.replace('\n', '').split(',')


if __name__ == "__main__":
    execute()
