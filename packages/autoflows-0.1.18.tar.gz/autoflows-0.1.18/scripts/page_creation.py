from coffee.client import JsonApiClient
from coffee.resource_handlers import FolderHandler
from coffee.schemas import api_schema_all


def execute():
    with JsonApiClient(schema=api_schema_all) as client:
        f_handler = FolderHandler(client)
        f = f_handler.get_by_name('LIMS').resource
        print(f)


if __name__ == '__main__':
    execute()
