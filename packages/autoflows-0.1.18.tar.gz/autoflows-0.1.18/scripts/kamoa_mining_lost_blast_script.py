from coffee.client import JsonApiClient
from coffee.resource_handlers import ConstantPropertyHandler, EventTypeHandler
from coffee.workflows import ConstantPropertyWorkflow, SeriesWorkflow, EventCollationWorkflow


def execute():
    with JsonApiClient() as client:
        # cp_workflow = ConstantPropertyWorkflow(client)
        # cp_workflow.bulk_create_constant_property(
        #     csv_path='scripts/data/kamoa_mining_lost_blast_cps_02_ton.csv'
        # )
        # assert True

        # series_workflow = SeriesWorkflow(client)
        # series_workflow.bulk_create_series(
        #     csv_path='scripts/data/kamoa_mining_lost_blast_series.csv'
        # )
        # assert True

        # cp_workflow.bulk_link_constant_property_to_event_type(
        #     csv_path='scripts/data/kamoa_mining_lost_blast_cps.csv'
        # )
        # assert True

        event_collation_workflow = EventCollationWorkflow(client)
        event_collation_workflow.bulk_create_collation_series_export(
            csv_path='scripts/data/kamoa_mining_lost_blast_collations_02.csv'
        )


if __name__ == '__main__':
    execute()
