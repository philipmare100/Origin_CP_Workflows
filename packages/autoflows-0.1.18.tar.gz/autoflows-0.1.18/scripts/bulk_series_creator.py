# older method self-contained
import json
import logging
import math
from typing import Optional, Dict, List, Tuple

import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
import os
import sys
from collections import defaultdict
import re
from typing import List, Union
from tqdm import tqdm
from dotenv import load_dotenv

load_dotenv()


class ValidityCheck:
    """
    This class encapsulates the validity checkers. The request or boto3 response is passed in a parameter to the class,
    and the appropriate response validity check method is called.
    """

    def __init__(self, response: requests.Response) -> None:
        self.response = response

    def check_boto3_response_validity(self):
        """
        This function checks the validity of a response and raises an exception if it does not have a status code of 200 or 404.
        This checker is specific to AWS SDK Boto3 and DynamoDB.
        """
        if self.response['ResponseMetadata']['HTTPStatusCode'] in [200, 204]:
            return True

        msg = self.response.get('Error', {}).get('Message', '')
        code = self.response.get('Error', {}).get('Code', '')
        if code == 'ValidationException':
            raise Exception(f'Invalid Request: {msg}')
        elif code == 'AccessDeniedException':
            raise Exception(f'Operation not Authorized: {msg}')
        elif code == 'UnrecognizedClientException':
            raise Exception(f'Authentication failed with the provided token: {msg}')
        elif code == 'InternalServerError':
            raise Exception(f'Client-side server error on DynamoDB: {msg}')
        elif code == 'BadGatewayException':
            raise Exception(f'Could not reach host: {msg}')
        else:
            raise Exception(f'Got {code} with message {msg}')

    def check_requests_response_validity(self):
        """
        This function checks the validity of a response and raises an exception if it does not have a status code of 200 or 404
        """
        if self.response.status_code in [200, 201, 204]:
            return True
            # Get Message:
        if hasattr(self.response, 'content'):
            msg = json.loads(self.response.content)
        elif hasattr(self.response, 'data'):
            msg = json.loads(self.response.data)
        elif hasattr(self.response, '_content'):
            msg = json.loads(self.response._content)
        elif hasattr(self.response, '_data'):
            msg = json.loads(self.response._data)
        else:
            raise Exception(f'Could not decode response content. Status code: {self.response.status_code}')

        if self.response.status_code == 400:
            raise Exception('Invalid Request', msg)
        elif self.response.status_code == 401:
            raise Exception('Operation not Authorized', msg)
        elif self.response.status_code == 403:
            raise Exception('Authentication failed with the provided token', msg)
        elif self.response.status_code == 500:
            raise Exception('Client-side server error on', msg)
        elif self.response.status_code == 502:
            raise Exception('Could not reach host', msg)
        else:
            raise Exception(f'Got Status {self.response.status_code}: {msg}')


class WIRESession:
    """
    A base class to handle the WIRE session. Logs into wire using the credentials provided.
     Generates an auth_obj that can be used for subsequent post and get requests.
    :param
    email -> user email
    password -> user's password. If not provided, the user must provide their security token obtained from 'My security page'
    token -> JWT of user, Not required if password is provided
    client_domain -> url of the client domain for example: htpps://kamoa.mmswire.com
    """

    def __init__(self, email: str, password: str, client_domain: str, verify_ssl: bool = False) -> None:
        # Private attributes
        self.__email = email
        self.__password = password

        # Auth object to be used during requests to WIRE
        self.auth_obj = HTTPBasicAuth(self.__email, self.__password)
        self.auth_data = json.dumps({'email': self.__email, 'password': self.__password})
        self.verify_ssl = verify_ssl
        # Client_domain and default headers to be used during requests to WIRE
        self.client_domain = client_domain
        self.default_headers = {'Content-Type': 'application/vnd.api+json'}

        # On instantiation the login details are checked
        self.__login()

    def __login(self):
        # Handle session authentication using self._auth_obj
        """Login into WIRE, and store the session and cookies."""

        login_url = self.client_domain + '/auth/login'
        auth_response = requests.post(url=login_url, data=self.auth_data, headers=self.default_headers, verify=self.verify_ssl)

        # Check the if one was able to login succesfully.
        ValidityCheck(auth_response).check_requests_response_validity()


class RequestHandler:
    def __init__(self, session: WIRESession) -> None:
        self.session = session

    def send_request(self, method: str, endpoint: str, params=None, json_data=None) -> requests.Response:
        url = self.session.client_domain + endpoint
        # Ensure method is uppercase
        method = method.upper()
        if method == 'GET':
            response = requests.get(url, params=params, headers=self.session.default_headers, auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'POST':
            response = requests.post(url, json=json_data, headers=self.session.default_headers, auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'PUT':
            response = requests.put(url, json=json_data, headers=self.session.default_headers, auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'PATCH':
            response = requests.patch(url, json=json_data, headers=self.session.default_headers, auth=self.session.auth_obj, verify=self.session.verify_ssl)
        elif method == 'DELETE':
            response = requests.delete(url, headers=self.session.default_headers, auth=self.session.auth_obj, verify=self.session.verify_ssl)
        else:
            raise ValueError("Unsupported HTTP method")

        return response


class WIREDataFetcher:
    """
    A Helper/Utility class to fetch related information from WIRE
    """

    def __init__(self, session: WIRESession, request_handler: RequestHandler) -> None:
        self.units_name_id_map: Dict[str, str] = dict()
        self.cp_id_cpet_id_map: Dict[str, str] = dict()
        self.session = session
        self.request_handler = request_handler

    def get_engineering_units_map(self) -> Dict[str, str]:
        # Fetch and return engineering units mapping

        endpoint = '/api/engineering_unit'
        engineering_unit_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(engineering_unit_response).check_requests_response_validity()
        fetched_data = json.loads(engineering_unit_response.text)['data']
        for engineering_unit in tqdm(fetched_data, desc='Fetching Engineering units'):
            fetched_id = engineering_unit['id']
            fetched_name = engineering_unit['attributes']['name']
            self.units_name_id_map[fetched_name] = fetched_id
        logging.info('Successfully retrieved `engineering_units_name_id_map`')
        return self.units_name_id_map

    def get_constant_property_event_type_id_map(self, event_type_id: str = 'dba94430-404b-453f-81f0-9a4dd5c4b366') -> Tuple[Dict[str, str], List[str]]:
        # Fetch and return constant property event type mapping

        endpoint = '/api/constant_property_event_type'

        constant_property_event_type_map_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(constant_property_event_type_map_response).check_requests_response_validity()
        fetched_data = json.loads(constant_property_event_type_map_response.text)['data']

        error_msgs: list[str] = []
        cp_id_cpet_id_map: Dict[str, str] = dict()

        for cpet in tqdm(fetched_data, desc='constructing constant_property event_type mapping:'):
            assert cpet['type'] == 'constant_property_event_type'

            try:
                if cpet['relationships']['event_type']['data']['id'] == event_type_id:
                    fetched_cpet_id = cpet['id']
                    fetched_cp_id = cpet['relationships']['constant_property']['data']['id']
                    cp_id_cpet_id_map[fetched_cp_id] = fetched_cpet_id
            except Exception as e:
                error_msgs.append(f'{type(e).__name__}: {e.args[0]}')

        if len(cp_id_cpet_id_map.keys()) > 0:
            logging.warning('Successfully retrieved `cp_id_cpet_id_map`')
            self.cp_id_cpet_id_map = cp_id_cpet_id_map
            return cp_id_cpet_id_map, error_msgs

        # Adding an empty return as incase the above if block does not get executed.
        return {}, error_msgs

    def get_component_id_by_name(self, process_name: str, series_name: str) -> str:
        # Fetch and return component ID by name
        endpoint = '/api/process?filter[name]=' + process_name
        component_id_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(component_id_response).check_requests_response_validity()
        if len(component_id_response.json()['data']) == 0:
            logging.warning(f"could not find a process named {process_name}, thus could not link series {series_name} ")
            return str()

        component_id = component_id_response.json()['data'][0]['id']
        return component_id

    def get_series_id_by_name(self, name: str) -> Optional[str]:
        if not name:
            return None
        # Fetch and return series ID by name
        endpoint = '/api/series?filter[name]=' + name
        series_id_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(series_id_response).check_requests_response_validity()
        response_data = series_id_response.json()['data']
        if response_data:
            series_id = response_data[0]['id']
            return series_id
        else:
            return None


    def get_series_type_id_by_name(self, name: str) -> Optional[str]:
        if not name:
            return None
        endpoint = '/api/series_type?filter[name]=' + name
        series_id_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(series_id_response).check_requests_response_validity()
        response_data = series_id_response.json()['data']
        if response_data:
            series_id = response_data[0]['id']
            return series_id
        else:
            return None

    def get_constant_property_id_by_name(self, name: str) -> Optional[str]:
        if not name:
            return None
        # Fetch and return constant property ID by name
        endpoint = '/api/constant_property?filter[name]=' + name
        constant_property_id_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(constant_property_id_response).check_requests_response_validity()
        response_data = constant_property_id_response.json()['data']
        if response_data:
            constant_property_id = response_data[0]['id']
            return constant_property_id
        else:
            return None

    def get_component_info(self, component_id: str) -> dict:
        # Fetch and return detailed component information
        pass

    def get_series_info(self, series_id: str) -> dict:
        # Fetch and return detailed series information
        endpoint = '/api/series?filter[id]=' + series_id
        series_id_response = self.request_handler.send_request(method='GET', endpoint=endpoint)
        ValidityCheck(series_id_response).check_requests_response_validity()
        response_data = series_id_response.json()['data']
        return response_data

    def get_constant_property_info(self, constant_property_id: str) -> dict:
        # Fetch and return detailed constant property information
        pass

    # Other data-fetching methods as needed


class VariableSorter:
    def __init__(self, csv_file: str):
        """
        Initialize the VariableSorter with a CSV file path.

        Args:
            csv_file (str): The path to the CSV file containing variable names and formulas.
        """
        self.csv_file = csv_file
        self.dependencies = defaultdict(list)
        self.visited = set()
        self.stack = set()
        self.has_cycle = False
        self.circular_references = []

    def read_csv(self) -> pd.DataFrame:
        """
        Read the CSV file and return a DataFrame.

        Returns:
            pandas.DataFrame: The DataFrame containing 'name' and 'formula' columns.
        """
        df = pd.read_csv(self.csv_file)
        return df

    def __extract_dependencies(self, formula: str) -> List[str]:
        """
        Extract variable dependencies from a formula.

        Args:
            formula (str): The formula string containing variable dependencies in square brackets.

        Returns:
            List[str]: A list of variable names extracted from the formula.
        """
        pattern = r'\[([^]]+)\]'
        variables = re.findall(pattern, formula)
        return variables

    def __dfs(self, node: str):
        """
        Perform depth-first search (DFS) to detect circular references.

        Args:
            node (str): The current node being visited in the dependency graph.
        """
        if self.has_cycle:
            return

        self.visited.add(node)

        # Check if node has dependencies
        if node not in self.dependencies:
            return

        self.stack.add(node)

        for neighbor in self.dependencies[node]:
            if neighbor not in self.visited:
                self.__dfs(neighbor)
            elif neighbor in self.stack:
                self.has_cycle = True
                self.circular_references.append(node)
                return

        self.stack.remove(node)

    def perform_topological_sort(self) -> Union[List[str], str]:
        """
        Perform topological sorting of variable names based on their dependencies.

        Returns:
            Union[List[str], str]: A sorted list of variable names if no circular references are detected,
                                   a message indicating the presence of circular references, and
                                   a list of variable names with circular references.
        """
        df = self.read_csv()
        df.fillna('', inplace=True)

        for index, row in df.iterrows():
            name = row['name']
            formula = row['formula']
            if type(formula) == str:
                variables = self.__extract_dependencies(formula)

                for var in variables:
                    if var != name:
                        self.dependencies[name].append(var)

        sorted_names = []
        for node in self.dependencies:
            if node not in self.visited:
                self.__dfs(node)
            if self.has_cycle:
                break

        if not self.has_cycle:
            sorted_names = list(self.__topological_sort(self.dependencies))
            return sorted_names[::-1], "No circular references", []
        else:
            return (
                "Circular reference detected. Cannot perform topological sorting.",
                "Circular references found:",
                self.circular_references,
            )

    def __topological_sort(self, graph: dict) -> List[str]:
        """
        Perform topological sorting of a directed graph.

        Args:
            graph (dict): A dictionary representing the directed graph with variable dependencies.

        Returns:
            List[str]: A list of variable names in topological order.
        """
        result = []

        def visit(node):
            if node not in self.visited:
                self.visited.add(node)
                for neighbor in graph[node]:
                    visit(neighbor)
                result.append(node)

        for node in graph:
            visit(node)

        return result[::-1]


class SeriesCreator:
    def __init__(self, session: WIRESession, wire_data_fetcher: WIREDataFetcher, request_handler: RequestHandler, topologically_sorted_names) -> None:
        self.process_linked_series: List[str] = list()
        self.calc_id_formula_map: Dict[str, str] = dict()
        self.created_series_ids: List[str] = list()
        self.session = session
        self.WIRE_data_fetcher = wire_data_fetcher
        self.request_handler = request_handler
        self.engineering_unit_id_map = self.WIRE_data_fetcher.units_name_id_map
        self.sorted_names = topologically_sorted_names

    def __create_single_series(self,
                               name: str,
                               description: str,
                               engineering_unit: Optional[str] = None,
                               aggregation: Optional[str] = None,
                               sample_period: Optional[str] = None,
                               fill_method: Optional[str] = None,
                               name_formula: Optional[str] = None,
                               weighted_average_series: Optional[str] = None,
                               source_series :str= None,
                               series_type :str = None):
        """
        This function creates the json object that used in a post-request to WIRE to create a series
        :param
        name -> name of the series to be created
        description -> description of the series
        engineering_unit -> the engineering unit name of the
        """
        endpoint = '/api/series'

        unit_id = self.engineering_unit_id_map.get(engineering_unit, None)
        base_json = {
            "data": {
                "type": "series",
                "attributes": {
                    "base_type": "series",
                    "account_name": None,
                    "accumulation": None,
                    "alias": None,
                    "allow_edit": None,
                    "alternate_names": None,
                    "assumptions": None,
                    "budget": None,
                    "changed_on": None,
                    "collector_names": None,
                    "created_on": None,
                    "decimal_places": None,
                    "default_chart": None,
                    "default_value": None,
                    "delete_hihilowlow": None,
                    "description": description,
                    "extra_arguments_string": "{}",
                    "fill_method": fill_method,
                    "hi": None,
                    "hihi": None,
                    "is_calculation": True if name_formula is not None else False,
                    "json": {
                        "comment": None
                    },
                    "kpi_level": None,
                    "linked_components": None,
                    "low": None,
                    "lowlow": None,
                    "mean": None,
                    "name": name,
                    "name_formula": name_formula if name_formula else None,
                    "rolling_average_hours": None,
                    "sample_offset": None,
                    "specialised_function": None,
                    "std": None
                },
                "relationships": {
                    "engineering_unit": {
                        "data": None
                    },
                    "series_type": {
                        "data": None
                    },
                    "event_type": {
                        "data": None
                    },
                    "weighted_average_series": {
                        "data": None
                    },
                    "created_by": {
                        "data": None
                    },
                    "changed_by": {
                        "data": None
                    },
                    "created_by_account": {
                    "data": None
                    },
                    "source_series": {
                        "data": None
                    },
                    "series_type": {
                        "data": None
                    }

                }
            }
        }

        if aggregation:
            base_json["data"]["attributes"]["aggregation"] = aggregation
        if sample_period:
            base_json["data"]["attributes"]["sample_period"] = sample_period
        if source_series:
            base_json["data"]["relationships"]["source_series"] = {
                "data":
                    [{
                        "id": self.WIRE_data_fetcher.get_series_id_by_name(source_series),
                        "type": "series"
                    }]
                }
        if series_type:
            base_json["data"]["relationships"]["series_type"] = {
                "data": {
                    "id": self.WIRE_data_fetcher.get_series_type_id_by_name(series_type),
                    "type": "series_type"
                }}
        if unit_id is not None:
            base_json['data']['relationships']['engineering_unit'] = {
                "data": {
                    "id": unit_id,
                    "type": "engineering_unit"
                }
            }
        if weighted_average_series is not None:
            base_json['data']['relationships']['weighted_average_series'] = {
                "data": {
                    "id": self.WIRE_data_fetcher.get_series_id_by_name(weighted_average_series),
                    "type": "series"
                }
            }

        result = self.request_handler.send_request(method='POST', endpoint=endpoint, json_data=base_json)

        try:
            ValidityCheck(result).check_requests_response_validity()
            logging.info(f'Successfully created {name}')
        except Exception as e:
            logging.error(f'Failed to create series named "{name}": {str(e)}')

    def __create_series_from_df(self, df) -> Dict[str, str]:
        """
        Create Series in bulk from DataFrame
        """
        # Replace `np.nan` with `None`, for better downstream processing
        # df = df.where(pd.notnull(df), None)
        df.fillna('None', inplace=True)
        self.WIRE_data_fetcher.get_engineering_units_map()
        for _, row in tqdm(df.iterrows(), desc='Creating series from csv:'):
            name = row['name']

            series_id = self.WIRE_data_fetcher.get_series_id_by_name(name)
            if series_id:
                logging.warning(f'Duplicate: Series <{name}> already exists!')
                continue

            description = row.get('description')
            engineering_unit = row.get('unit', None)
            name_formula = row.get('formula', None)
            source_series = row.get('source_series', None)
            series_type = row.get('series_type', None)
            aggregation = row.get('aggregation', None)
            sample_period = row.get('sample_period', None)
            weighted_average_series = row.get('weighted_average_series', None) if aggregation == 'weighted_average' else None

            series_id = self.WIRE_data_fetcher.get_series_id_by_name(name)

            if series_id:
                logging.warning(f'Duplicate: Series <{name}> already exists!')
                self.__update_calc(name, series_id, sample_period, name_formula)
                continue

            self.__create_single_series(name=name,
                                        description=description,
                                        engineering_unit=engineering_unit,
                                        aggregation=aggregation,
                                        sample_period=sample_period,
                                        fill_method=None,
                                        name_formula=name_formula,
                                        weighted_average_series=weighted_average_series,
                                        source_series=source_series,
                                        series_type=series_type
                                        )

    def __link_series_to_component(self,
                                   series_name=None,
                                   component_name=None):
        """
        A function that links a single series to a single process
        :param
        series_name -> name of the series to be linked to a process
        component_name -> the process name to which a series will be linked

        """
        series_id = self.WIRE_data_fetcher.get_series_id_by_name(series_name)
        component_id = self.WIRE_data_fetcher.get_component_id_by_name(component_name, series_name)
        endpoint = '/api/series_component'
        link_obj = {
            'data': {
                'type': 'series_component',
                'relationships': {
                    'component': {
                        'data': {
                            'id': component_id,
                            'type': 'component'
                        }
                    },
                    'series': {
                        'data': {
                            'id': series_id,
                            'type': 'series'
                        }
                    }
                }
            }
        }

        response = self.request_handler.send_request(method='POST', endpoint=endpoint, json_data=link_obj)

        if response.status_code != 201:
            logging.warning(f'{series_name}error code is {response.status_code} and the reason is {response.reason} /n the response is {response.text}')
        else:
            logging.info(f'{series_name} linked to process successfully')

    def __bulk_link_series_to_process(self, df):

        for _, row in tqdm(df.iterrows(), desc='linking series to processes:'):
            series_name = row.get('name')
            component_name = row.get('process_name')

            if component_name not in self.process_linked_series:
                self.__link_series_to_component(series_name=series_name,
                                                component_name=component_name)
                self.process_linked_series.append(series_name)

    def __update_calc(self, name, id, sample_period: Optional[str] = None, name_formula: Optional[str] = None):
        if not name_formula:
            return
        json_data = {
            "data": {
                "type": "series",
                'id': str(id),
                "attributes": {
                    "base_type": "series",
                    "is_calculation": True if name_formula is not None else False,
                    "name_formula": name_formula if name_formula else None,
                    "sample_period": sample_period,
                    "specialised_function": None,
                },
            }
        }

        logging.warning(f'Updating Series <{name}> to calculation')
        endpoint = f'/api/series/{id}'
        result = self.request_handler.send_request(method='PATCH', endpoint=endpoint, json_data=json_data)

        try:
            ValidityCheck(result).check_requests_response_validity()
            logging.info(f'Successfully updated {name}')
        except Exception as e:
            logging.error(f'Failed to update series named "{name}": {str(e)}')


    def execute(self, series_file: str) -> Dict[str, str]:
        """


        :param series_file:
        :return:
        """

        df = pd.read_csv(series_file)

        self.__create_series_from_df(df)
        self.__bulk_link_series_to_process(df)
        return calc_id_map


class SeriesCalculationManager:
    def __init__(self, session: WIRESession, wire_data_fetcher: WIREDataFetcher, requests_handler: RequestHandler, calc_id_formula_map: Dict[str, str]):
        self.__created_calcs: List[str] = []
        self.__dirty_upgrade_calcs: List[str] = []
        self.session = session
        self.wire_data_fetcher = wire_data_fetcher
        self.request_handler = requests_handler
        self.calc_id_formula_map = calc_id_formula_map

    def __patch_formula(self,
                        calc_id,
                        formula) -> str:
        """
        ToDo: Add a docstring
        """
        endpoint = '/api/calculation/' + calc_id
        patch_obj = {
            'data': {
                'id': calc_id,
                'type': 'calculation',
                'attributes': {
                    'name_formula': formula
                }
            }
        }
        result = self.request_handler.send_request(method='PATCH', endpoint=endpoint, json_data=patch_obj)
        if result.status_code != 200:
            try:
                msg = result.json()['data']['message']
                raise Exception(f'Failed to create calculation with formula {formula}: {msg}')
            except:
                raise Exception(str(result.__dict__))
        else:
            return calc_id

    def __upgrade_created_series_to_calculation(self) -> None:
        if self.calc_id_formula_map:
            upgrades_calcs: List[str] = []

            for calc_id, formula in tqdm(self.calc_id_formula_map.items(), desc='Upgrading series to calcs:'):
                endpoint = '/api/utils/upgrade_series_to_calc/' + calc_id
                response = self.request_handler.send_request(method='GET', endpoint=endpoint)
                try:
                    if response.status_code != 200:
                        msg = response.json()['message']
                        logging.warning(f'Failed to upgrade calculation with formula {formula}: {msg}, checking if it is an empty formula... ')
                        if msg == 'Series base type is not of type series':
                            series_info = self.wire_data_fetcher.get_series_info(series_id=calc_id)
                            if series_info[0]['attributes']['base_type'] == 'calculation' and len(series_info[0]['attributes']['name_formula']) == 0|1:
                                msg = f'series {calc_id} was already a calculation, but has an empty formula, proceeding to update formula '
                                logging.info(msg)
                                self.__created_calcs.append(calc_id)
                                calc_id = self.__patch_formula(calc_id, formula)
                                upgrades_calcs.append(calc_id)
                            else:
                                msg = f'series {calc_id}, with formula {formula} is a calculation with an existing formula will not upgrade '
                                logging.warning(msg)
                                self.__dirty_upgrade_calcs.append(calc_id)
                                continue

                    self.__created_calcs.append(calc_id)
                    calc_id = self.__patch_formula(calc_id, formula)
                    upgrades_calcs.append(calc_id)
                except Exception as e:
                    logging.error(f'Unable to create calculation due to this error: {str(e)}')

            for calc_id in upgrades_calcs:
                self.calc_id_formula_map.pop(calc_id)
        else:
            logging.warning('Empty: No calculations to upgrade.')

    def execute_calculation_upgrade(self, df):
        if len(self.calc_id_formula_map) != len(df[pd.notna(df['formula'])]):
            msg = (f'There is a miss match between the number of calculations found in the csv file, '
                   f'and ones that were created\n'
                   f' Number calcs of found in csv file: {len(df[pd.notna(df["formula"])])}\n'
                   f'Number of new calcs to be created: {len(self.calc_id_formula_map)}\n'
                   f'This normally happens when a csv file was already used to bulk upload series '
                   f'but something went wrong during the initial upgrade procedure\n'
                   f'You can either choose to only upgrade new series that have a formula or you can '
                   f'choose to upgrade all series that have a formula')
            logging.info(msg)
            upgrade_all_anyway = (lambda response: True if response == 'y' else False)(input('Would you like to upgrade all series that have a formula?[y/n]?').lower())

            if upgrade_all_anyway:
                raw_series_calc_map: Dict[str, str] = dict()
                all_calc_id_map: Dict[str, str] = dict()
                for _, row in df.iterrows():
                    series_name = row['name']
                    formula = row['formula']
                    if type(formula) == float and math.isnan(formula):
                        continue
                    raw_series_calc_map[series_name] = formula
                    series_id = self.wire_data_fetcher.get_series_id_by_name(name=series_name)
                    all_calc_id_map[series_name] = series_id

                # Create a new dictionary with series_id as keys and formula as values
                all_calc_id_formula_map = {all_calc_id_map[series_name]: formula for series_name, formula in raw_series_calc_map.items()}
                self.calc_id_formula_map = all_calc_id_formula_map
                self.__upgrade_created_series_to_calculation()

        else:
            self.__upgrade_created_series_to_calculation()


class EventCollationManager:
    def __init__(self, session: WIRESession, cp_id_cpet_id_map: Dict[str, str]):
        self.session = session
        self.cp_id_cpet_id_map = cp_id_cpet_id_map

    def create_event_collation(self, series_name, constant_property_name):
        # ... same implementation as before ...
        pass

    def bulk_event_collation(self, df):
        for i in range(len(df.index)):
            row = df.iloc[i, :]
            series_name = row["series_name"]
            constant_property_name = row["constant_property_name"]
            self.create_event_collation_link(series_name, constant_property_name)


def setup_logging(log_file_path):
    # Configure the root logger
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    # Create a FileHandler and set its formatter
    file_handler = logging.FileHandler(log_file_path)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)

    # Add the FileHandler to the root logger
    logging.getLogger().addHandler(file_handler)


def main(filepath = None):
    # Setup the file path for logging.
    current_directory = os.getcwd()
    log_file_name = "WIRE_Configuration_logs.txt"
    full_path = os.path.join(current_directory, log_file_name)
    setup_logging(full_path)

    if (filepath):
        email = os.getenv('wire_username', None)
        pwd = os.getenv('wire_password', None)
        client_domain = os.getenv('client_domain', None)
        base_folder_path = os.getenv('base_folder_path', None)
    else:
        # Asking for the user input.
        use_env = input("Would you like to use the .env file for basic inputs?[y|n]:").lower()
        if use_env == 'y':
            msg = 'Using the .env to load basic inputs...'
            logging.info(msg)
            email = os.getenv('wire_username', None)
            pwd = os.getenv('wire_password', None)
            client_domain = os.getenv('client_domain', None)
            base_folder_path = os.getenv('base_folder_path', None)
            if email is None or pwd is None:
                msg = f'Missing entries in the .env file, please enter them manually'
                logging.info(msg)
                email = input("Please enter email address to be used to upload data to WIRE: ")
                pwd = input("Please enter your password: ")
        if pwd is None:
            token = input("You didn't enter a password, please enter your security token: ")
        elif use_env == 'n':
            email = input("Please enter email address to be used to upload data to WIRE: ")
            pwd = input("Please enter your password: ")
            client_domain = input("Please enter the client domain: ")

        filepath = input("Please enter the filename to the CSV: ")

    wire_session = WIRESession(email=email, password=pwd, client_domain=client_domain)
    requests_handler = RequestHandler(session=wire_session)
    wire_data_fetcher = WIREDataFetcher(session=wire_session, request_handler=requests_handler)

    if base_folder_path:
        full_filepath = os.path.join(base_folder_path, filepath)
    else:
        msg = f'No base file path was provided'
        logging.warning(msg)
        full_filepath = input("Please enter the full filepath to the CSV: ")

    sorted_series_list = []
    ### Note, commenting out the topological sort as it doesn't work in it's current form.
    # Adding topological sort to check for circular references and provide feedback about it.
    # topological_sorter = VariableSorter(full_filepath)
    # sorted_names, message, circular_references = topological_sorter.perform_topological_sort()
    # if message == "No circular references":
    #     sorted_series_list = sorted_names
    # else:
    #     logging.error(message)
    #     logging.error(circular_references)
    #     raise Exception(message)

    series_creator = SeriesCreator(session=wire_session, wire_data_fetcher=wire_data_fetcher, request_handler=requests_handler,topologically_sorted_names=sorted_series_list)
    series_creator.execute(series_file=full_filepath)

if __name__ == '__main__':
    filepath = None
    if (len(sys.argv) > 1):
        filepath = sys.argv[1]
    main(filepath)
