import math
import os
import time
import yaml
import base64
import logging
import warnings

import requests
from dotenv import load_dotenv
from dateutil.parser import parse
from datetime import timedelta, datetime
from tqdm import tqdm

load_dotenv()

logging.basicConfig(filename='process_log.log', level=logging.INFO,
                    format='%(asctime)s | %(levelname)s | %(message)s')
warnings.filterwarnings("ignore", message="Unverified HTTPS request")


def save_time_cursor(time_cursor, file_path):
    """Function to save the time cursor to a yaml file"""
    with open(file_path, 'w') as file:
        yaml.dump({'time_cursor': time_cursor.isoformat()}, file)


def load_time_cursor(file_path):
    """Function to load the time cursor from a yaml file"""
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        return parse(data['time_cursor'])


def make_request_with_backoff(url, headers, max_wait=100):
    backoff_time = 1  # Start with 1 second
    while True:
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            return response
        else:
            logging.error(f'Error: {response.status_code} | {response.json()}. Retrying in {backoff_time} seconds...')
            time.sleep(backoff_time)
            backoff_time *= 2  # Double the wait time for the next iteration
            if backoff_time > max_wait:
                backoff_time = max_wait  # Cap the wait time at max_wait seconds


def execute(username='h',
            time_cursor_path='bulk_import_time_cursor.yaml',
            series_string_fpath='mtk_bulk_import_series_string.txt',
            time_delta_hours=3):
    api_token = os.getenv('API_TOKEN')
    auth_header = {
        'Authorization': 'Basic ' + base64.b64encode(f"{username}:{api_token}".encode()).decode("ascii"),
        'Content-type': 'application/json'
    }
    base_url = os.getenv(
        'API_BASE_URL') + "/utils/BulkImportOpsData?series_string={series_string}&start={start}&end={end}"

    time_cursor = load_time_cursor(time_cursor_path)
    stop_time = datetime.now()

    names_list = load_series_string(series_string_fpath)

    total_iterations = math.ceil((stop_time - time_cursor) / timedelta(hours=time_delta_hours))
    logging.info(f"=================== Start Process for Time '{time_cursor}' to '{stop_time}' =================")
    logging.info(f'Total Iterations: {total_iterations}')
    progress_bar = tqdm(total=total_iterations, desc="Time")

    while time_cursor < stop_time:
        q_start = time_cursor.isoformat()
        end = time_cursor + timedelta(hours=time_delta_hours)
        logging.info(f"Aggregating from {time_cursor} to {end}")
        q_end = end.isoformat()
        for s in tqdm(names_list, desc="Series", leave=False):
            url = base_url.format(series_string=s, start=q_start, end=q_end)
            make_request_with_backoff(url, auth_header)
            # Since we return the response only on success, no need to assert here.
            logging.info(f"{datetime.now()} | Aggregated from {time_cursor} to {end}")
        time_cursor = end

        save_time_cursor(time_cursor, time_cursor_path)
        progress_bar.update(1)

    progress_bar.close()
    logging.info(
        f"====================== End Process for Time '{time_cursor}' to '{stop_time}' =====================")


def load_series_string(filename) -> list[str]:
    with open(filename, 'r') as file:
        data = file.read()
    return data.replace('\n', '').split(',')


if __name__ == "__main__":
    execute()
