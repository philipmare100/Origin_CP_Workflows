# older method self-contained
import base64
import os
import sys
from typing import Dict

import requests
import json
import pandas as pd

DOMAIN = ''
USERNAME = ''
TOKEN = ''
AUTH_HEADER = {
    'Authorization': 'Basic %s' % base64.b64encode(bytes(("{}:{}".format(USERNAME, TOKEN)).encode('utf-8'))).decode("ascii"),
    'Content-type': 'application/vnd.api+json'
}


class SeriesExists(Exception):
    pass


def check_duplicate_error(response, name):
    error = json.loads(response.content)
    if 'uniqueviolation' in str(error).lower():
        raise SeriesExists()
    raise Exception(f'Failed to create mapper {name}: {error}')


def upsert_mapper(domain, source_name, series_id, collector_id, aggregation) -> requests.Response:
    mapper_data = {
        "data": {
            "type": "mapper",
            "attributes": {
                "source_name": source_name,
                "aggregation_method": aggregation
            },
            "relationships": {
                "series": {
                    "data": {"type": "series", "id": series_id}
                },
                "collector": {
                    "data": {"type": "collector", "id": collector_id}
                }
            }
        }
    }

    url = f'{domain}/api/mapper'

    response = requests.post(url, json=mapper_data, headers=AUTH_HEADER)
    return response


def get_id_name_map_for_type(names, model, domain) -> Dict[str, str]:
    """Maps names in the csv to ids in WIRE via REST API call"""
    filters = {"name": "name", "op": "in", "val": names}
    url = (domain + f'/api/{model}?filter=[' + json.dumps(filters)).replace(' ', '') + ']'
    response = requests.get(url, headers=AUTH_HEADER)
    if response.status_code >= 400:
        raise Exception(f'Failed with status {response.status_code}\n\n{response.json}')

    obj_name_id_map = dict()
    for obj in json.loads(response._content)['data']:
        obj_name = obj['attributes']['name']
        obj_id = obj['id']
        obj_name_id_map[obj_name] = obj_id

    return obj_name_id_map


def post_mappers(df: pd.DataFrame, errors: list, successes: list):
    series_name_id_map: dict = get_id_name_map_for_type(list(set(df['series'])), 'series', DOMAIN)
    collector_name_id_map: dict = get_id_name_map_for_type(list(set(df['collector'])), 'collector', DOMAIN)

    for i, row in df.iterrows():
        source_name = row['source_name']
        series_id = series_name_id_map[row['series']]
        collector_id = collector_name_id_map[row['collector']]
        aggregation = row.get('aggregation')

        response = upsert_mapper(DOMAIN, source_name, series_id, collector_id, aggregation)
        if response.status_code != 201:
            check_duplicate_error(response, source_name)
            errors.append(source_name)
        else:
            if i % 20 == 0:
                print(f'\nCompleted {i} mappers\n')
            successes.append(source_name)


def get_df_from_name_or_input() -> pd.DataFrame:
    if len(sys.argv) > 1:
        filepath = sys.argv[1]
    else:
        filepath = input("\nEnter file path:\n>")
        while not os.path.exists(os.path.expanduser(filepath)) or not filepath.endswith('.csv'):
            filepath = input(f"Invalid path {filepath}, try again:\n>")

    df = pd.read_csv(filepath)
    df.columns = [x.lower() for x in df.columns]
    return df


def __main__():
    """
    Expects a csv with columns: series | source_name | collector [| optional: aggregation]
    """
    df: pd.DataFrame = get_df_from_name_or_input()

    successes = []
    errors = []
    post_mappers(df, successes, errors)

    print(f'Successes:{len(successes)}\nErrors: {errors}')


if __name__ == '__main__':
    __main__()
