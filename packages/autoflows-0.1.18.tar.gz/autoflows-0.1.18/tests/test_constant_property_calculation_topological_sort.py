import pandas as pd

from coffee.utils.calc_helpers import sort_data_topological


# # Assuming df is your DataFrame with columns ['name', 'formula', 'is_calculation']
# # Create a sample DataFrame
# def generate_test_df():
#     data_mod = {
#         'name': ['DEMO_CP01_DIM', 'DEMO_CP02_DIM', 'DEMO_CP03_DIM', 'DEMO_CP04_DIM', 'DEMO_CP05_DIM',
#                  'DEMO_CP06_DIM', 'DEMO_CP07_DIM', 'DEMO_CP08_DIM', 'DEMO_CP09_DIM', 'DEMO_CP10_DIM',
#                  'DEMO_CP11_DIM', 'DEMO_CP12_DIM', 'DEMO_CP13_DIM', 'DEMO_CP14_DIM', 'DEMO_CP15_DIM'],
#         'formula': ['100',  # Simple value, no reference
#                     '50',  # Simple value, no reference
#                     '[DEMO_CP01_DIM] * 2',  # References CP01
#                     '[DEMO_CP02_DIM] + 10',  # References CP02
#                     '[DEMO_CP03_DIM] - 5',  # References CP03
#                     '[DEMO_CP04_DIM] / 2',  # References CP04
#                     '[DEMO_CP05_DIM] ** 2',  # References CP05
#                     '[DEMO_CP01_DIM] + [DEMO_CP06_DIM]',  # References CP01 and CP06
#                     '[DEMO_CP07_DIM] - [DEMO_CP02_DIM]',  # References CP07 and CP02
#                     '[DEMO_CP08_DIM] * 3',  # References CP08
#                     '[DEMO_CP09_DIM] + 200',  # References CP09
#                     '[DEMO_CP10_DIM] / [DEMO_CP03_DIM]',  # References CP10 and CP03
#                     '300',  # Simple value, no reference
#                     '[DEMO_CP11_DIM] - 100',  # References CP11
#                     '[DEMO_CP12_DIM] ** 2'],  # References CP12
#         'is_calculation': [True, True, True, True, True, True, True, True, True, True, True, True, True, True, True]
#     }
#
#     # Adjusting the calculation flags to ensure 30% are not calculations
#     # Ensuring no circular references and respecting CP creation order
#     for i in range(len(data_mod['is_calculation'])):
#         if i % 3 == 0:  # Simplified condition to mark approximately 30% as non-calculations
#             data_mod['is_calculation'][i] = False
#
#     df_no_circular = pd.DataFrame(data_mod)
#     df_no_circular.loc[~df_no_circular['is_calculation'], 'formula'] = None
#     return df_no_circular
#
#
# df = generate_test_df()
# df = sort_data_topological(df)

assert 1 == 1

# print(df)
