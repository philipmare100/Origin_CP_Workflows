import pandas as pd
import pytest

from coffee.utils.calc_helpers import sort_data_topological
from coffee.exceptions import InvalidCalculationGraphException

assert 1 == 1
# def load_test_data():
#     return pd.read_csv('coffee/tests/data/test_constant_properties_data.csv')
#
#
# def test_sort_and_split():
#     """Tests correct sorting and separation of calculation graph items."""
#     df = load_test_data()
#     df = df.drop('is_calculation', axis=1)
#     in_calc_tree, independent_df = sort_data_topological(df, 'name_formula',
#                                                          children_col='variables', split=True)
#
#     # Assert 'is_calculation' is only True in 'in_calc_tree'
#     assert not any(independent_df['is_calculation'])
#
#     # Assert expected elements based on dependencies  (you'll need to adapt/add more):
#     in_calc_tree_expected = {
#         'DEMO_CP01_DIM',
#         'DEMO_CP02_DIM',
#         'DEMO_CP03_DIM',
#         'DEMO_CP04_DIM',
#         'DEMO_CP05_DIM',
#         'DEMO_CP06_DIM',
#         'DEMO_CP07_DIM',
#         'DEMO_CP08_DIM',
#         'DEMO_CP09_DIM',
#         'DEMO_CP10_DIM',
#         'DEMO_CP11_DIM',
#         'DEMO_CP12_DIM',
#         'DEMO_CP14_DIM',
#         'DEMO_CP15_DIM'
#     }
#     assert in_calc_tree_expected.issubset(set(in_calc_tree['name']))
#
#
# def test_circular_dependency():
#     """Tests that a suitable exception is raised in case of circular references."""
#     df = load_test_data()
#     # ... (Modify your DataFrame to create a circular dependency) ...
#
#     with pytest.raises(InvalidCalculationGraphException):
#         sort_data_topological(df, 'name_formula')
#
#
# if __name__ == '__main__':
#     test_sort_and_split()
