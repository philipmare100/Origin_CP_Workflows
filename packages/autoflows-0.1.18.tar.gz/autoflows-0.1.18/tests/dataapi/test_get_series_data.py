import pytest
import pandas as pd
from coffee.client import DataClient
from coffee.dataapi.dataobject import SeriesDataObject
from coffee.exceptions import NoDataReturnedException
from requests.exceptions import HTTPError


@pytest.fixture
def client():
    """Fixture to initialize the DataClient for tests."""
    return DataClient(base_url="https://coffee.com/api", auth=("user", "token"), verify_ssl=True)


def test_get_data_success_single_series(mocker, client):
    """Test get_data successfully handles a single series and returns a DataFrame."""
    # Mock response data with longer timestamps
    mock_response_data = {
        "data": {
            "SERIES01": {
                "2024-09-02T04:00:00.123456Z": 0.0,
                "2024-09-03T04:00:00.654321Z": 0.0
            }
        },
        "quality": {
            "SERIES01": {
                "2024-09-02T04:00:00.123456Z": 1,
                "2024-09-03T04:00:00.654321Z": 1
            }
        },
        "missing_values": {
            "SERIES01": {
                "2024-09-02T04:00:00.123456Z": True,
                "2024-09-03T04:00:00.654321Z": False
            }
        },
        "uncertainties": {}
    }

    # Mock the requests.request method
    mock_request = mocker.patch('coffee.client.requests.request')
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data
    mock_request.return_value = mock_response

    # Call get_data and get the SeriesDataObject
    series_data_object = client.get_data(start="2024-09-01", end="2024-09-03", series_list=["SERIES01"])
    df = series_data_object.to_dataframe()

    # Expected DataFrame structure with longer timestamps
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T04:00:00.123456Z", "2024-09-03T04:00:00.654321Z"]),
        "SERIES01": [0.0, 0.0],
        "SERIES01_quality": [1, 1],
        "SERIES01_missing": [True, False]
    })

    # Ensure the columns are in the correct order
    df = df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing']]
    expected_df = expected_df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the returned DataFrame matches the expected result
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_get_data_success_multiple_series(mocker, client):
    """Test get_data successfully handles multiple series and returns a DataFrame."""
    mock_response_data = {
        "data": {
            "SERIES01": {
                "2024-09-02T05:00:00.123456Z": 0.0,
                "2024-09-03T05:00:00.654321Z": 1.0
            },
            "SERIES02": {
                "2024-09-02T05:00:00.123456Z": 2.0,
                "2024-09-03T05:00:00.654321Z": 3.0
            }
        },
        "quality": {
            "SERIES01": {
                "2024-09-02T05:00:00.123456Z": 1,
                "2024-09-03T05:00:00.654321Z": 1
            },
            "SERIES02": {
                "2024-09-02T05:00:00.123456Z": 2,
                "2024-09-03T05:00:00.654321Z": 2
            }
        },
        "missing_values": {
            "SERIES01": {
                "2024-09-02T05:00:00.123456Z": False,
                "2024-09-03T05:00:00.654321Z": True
            },
            "SERIES02": {
                "2024-09-02T05:00:00.123456Z": False,
                "2024-09-03T05:00:00.654321Z": False
            }
        },
        "uncertainties": {}
    }

    mock_request = mocker.patch('coffee.client.requests.request')
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data
    mock_request.return_value = mock_response

    # Call get_data and get the SeriesDataObject
    series_data_object = client.get_data(start="2024-09-01", end="2024-09-03", series_list=["SERIES01", "SERIES02"])
    df = series_data_object.to_dataframe()

    # Expected DataFrame structure
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T05:00:00.123456Z", "2024-09-03T05:00:00.654321Z"]),
        "SERIES01": [0.0, 1.0],
        "SERIES01_quality": [1, 1],
        "SERIES01_missing": [False, True],
        "SERIES02": [2.0, 3.0],
        "SERIES02_quality": [2, 2],
        "SERIES02_missing": [False, False]
    })

    # Ensure the columns are in the correct order
    df = df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing',
             'SERIES02', 'SERIES02_quality', 'SERIES02_missing']]
    expected_df = expected_df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing',
                               'SERIES02', 'SERIES02_quality', 'SERIES02_missing']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the returned DataFrame matches the expected result
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_get_data_no_data(mocker, client):
    """Test that get_data raises NoDataReturnedException when no data is returned."""
    mock_request = mocker.patch('coffee.client.requests.request')

    # Mock the response to return no data
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {'data': {}}
    mock_request.return_value = mock_response

    # Expect NoDataReturnedException to be raised when no data is returned
    with pytest.raises(NoDataReturnedException):
        client.get_data(start="2024-09-01", end="2024-09-03")


def test_get_data_http_error(mocker, client):
    """Test that get_data raises an HTTPError when the request fails with an HTTP error."""
    mock_request = mocker.patch('coffee.client.requests.request')

    # Mock the response to simulate an HTTP error
    mock_response = mocker.Mock()
    mock_response.status_code = 500
    mock_response.raise_for_status.side_effect = HTTPError("500 Server Error")
    mock_request.return_value = mock_response

    # Expect an HTTPError to be raised due to the HTTP error
    with pytest.raises(HTTPError):
        client.get_data(start="2024-09-01", end="2024-09-03")


def test_get_data_missing_quality_values(mocker, client):
    """Test that get_data handles missing quality or missing values."""
    mock_response_data = {
        "data": {
            "SERIES01": {
                "2024-09-02T06:00:00.123456Z": 0.0,
                "2024-09-03T06:00:00.654321Z": 1.0
            }
        },
        "quality": {},  # No quality information
        "missing_values": {},  # No missing values information
        "uncertainties": {}
    }

    mock_request = mocker.patch('coffee.client.requests.request')
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data
    mock_request.return_value = mock_response

    # Call get_data and get the SeriesDataObject
    series_data_object = client.get_data(start="2024-09-01", end="2024-09-03", series_list=["SERIES01"])
    df = series_data_object.to_dataframe()

    # Expected DataFrame structure
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T06:00:00.123456Z", "2024-09-03T06:00:00.654321Z"]),
        "SERIES01": [0.0, 1.0]
    })

    # Ensure the columns are in the correct order
    df = df[['timestamp', 'SERIES01']]
    expected_df = expected_df[['timestamp', 'SERIES01']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the returned DataFrame matches the expected result
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_get_data_handles_uncertainties(mocker, client):
    """Test that get_data handles uncertainties in the response."""
    mock_response_data = {
        "data": {
            "SERIES01": {
                "2024-09-02T07:00:00.123456Z": 0.0,
                "2024-09-03T07:00:00.654321Z": 1.0
            }
        },
        "quality": {
            "SERIES01": {
                "2024-09-02T07:00:00.123456Z": 1,
                "2024-09-03T07:00:00.654321Z": 1
            }
        },
        "missing_values": {
            "SERIES01": {
                "2024-09-02T07:00:00.123456Z": False,
                "2024-09-03T07:00:00.654321Z": False
            }
        },
        "uncertainties": {
            "SERIES01": {
                "2024-09-02T07:00:00.123456Z": 0.1,
                "2024-09-03T07:00:00.654321Z": 0.05
            }
        }
    }

    mock_request = mocker.patch('coffee.client.requests.request')
    mock_response = mocker.Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data
    mock_request.return_value = mock_response

    # Call get_data and get the SeriesDataObject
    series_data_object = client.get_data(start="2024-09-01", end="2024-09-03", series_list=["SERIES01"])
    df = series_data_object.to_dataframe()

    # Expected DataFrame structure with uncertainties
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T07:00:00.123456Z", "2024-09-03T07:00:00.654321Z"]),
        "SERIES01": [0.0, 1.0],
        "SERIES01_quality": [1, 1],
        "SERIES01_missing": [False, False],
        "SERIES01_uncertainty": [0.1, 0.05]
    })

    # Ensure the columns are in the correct order
    df = df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing', 'SERIES01_uncertainty']]
    expected_df = expected_df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing', 'SERIES01_uncertainty']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the returned DataFrame matches the expected result
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_series_data_object_attributes():
    """Test that SeriesDataObject sets attributes correctly, including unwrapped query parameters."""
    # Sample input data
    data = {
        "SERIES01": {
            "2024-09-02T08:00:00.123456Z": 0.0,
            "2024-09-03T08:00:00.654321Z": 1.0
        }
    }
    quality = {
        "SERIES01": {
            "2024-09-02T08:00:00.123456Z": 1,
            "2024-09-03T08:00:00.654321Z": 1
        }
    }
    missing_values = {
        "SERIES01": {
            "2024-09-02T08:00:00.123456Z": False,
            "2024-09-03T08:00:00.654321Z": True
        }
    }
    uncertainties = {
        "SERIES01": {
            "2024-09-02T08:00:00.123456Z": 0.1,
            "2024-09-03T08:00:00.654321Z": 0.05
        }
    }

    # Query parameters (some with leading underscores to test they are not set)
    query_params = {
        "start": "2024-09-01",
        "end": "2024-09-03",
        "sample_period": "daily",
        "_protected_param": "should_not_be_set",
        "format": "columns"
    }

    # Create SeriesDataObject
    series_data_object = SeriesDataObject(
        data=data,
        quality=quality,
        missing_values=missing_values,
        uncertainties=uncertainties,
        **query_params
    )

    # Test that data, quality, missing_values, uncertainties are DataFrames
    assert isinstance(series_data_object.data, pd.DataFrame)
    assert isinstance(series_data_object.quality, pd.DataFrame)
    assert isinstance(series_data_object.missing_values, pd.DataFrame)
    assert isinstance(series_data_object.uncertainties, pd.DataFrame)

    # Test that query parameters are set as attributes
    assert series_data_object.start == "2024-09-01"
    assert series_data_object.end == "2024-09-03"
    assert series_data_object.sample_period == "daily"
    assert series_data_object.format == "columns"

    # Test that protected parameters are not set
    assert not hasattr(series_data_object, '_protected_param')

    # Test the to_dataframe method
    df = series_data_object.to_dataframe()

    # Expected DataFrame
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T08:00:00.123456Z", "2024-09-03T08:00:00.654321Z"]),
        "SERIES01": [0.0, 1.0],
        "SERIES01_quality": [1, 1],
        "SERIES01_missing": [False, True],
        "SERIES01_uncertainty": [0.1, 0.05]
    })

    # Ensure the columns are in the correct order
    df = df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing', 'SERIES01_uncertainty']]
    expected_df = expected_df[['timestamp', 'SERIES01', 'SERIES01_quality', 'SERIES01_missing', 'SERIES01_uncertainty']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the DataFrames are equal
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_series_data_object_missing_optional_fields():
    """Test that SeriesDataObject handles missing optional fields correctly."""
    # Sample input data with only 'data'
    data = {
        "SERIES01": {
            "2024-09-02T09:00:00.123456Z": 0.0,
            "2024-09-03T09:00:00.654321Z": 1.0
        }
    }

    # Create SeriesDataObject with only 'data'
    series_data_object = SeriesDataObject(
        data=data,
        start="2024-09-01",
        end="2024-09-03"
    )

    # Test that data is a DataFrame, others are None
    assert isinstance(series_data_object.data, pd.DataFrame)
    assert series_data_object.quality is None
    assert series_data_object.missing_values is None
    assert series_data_object.uncertainties is None

    # Test that query parameters are set
    assert series_data_object.start == "2024-09-01"
    assert series_data_object.end == "2024-09-03"

    # Test the to_dataframe method
    df = series_data_object.to_dataframe()

    # Expected DataFrame
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime(["2024-09-02T09:00:00.123456Z", "2024-09-03T09:00:00.654321Z"]),
        "SERIES01": [0.0, 1.0]
    })

    # Ensure columns are in correct order
    df = df[['timestamp', 'SERIES01']]
    expected_df = expected_df[['timestamp', 'SERIES01']]

    # Reset index for comparison
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the DataFrames are equal
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)


def test_series_data_object_multiple_series_different_timestamps():
    """Test SeriesDataObject with multiple series that have different timestamps."""
    # Sample data with different timestamps for each series
    data = {
        "SERIES01": {
            "2024-09-02T10:00:00.123456Z": 0.0,
            "2024-09-03T10:00:00.654321Z": 1.0
        },
        "SERIES02": {
            "2024-09-02T11:00:00.123456Z": 2.0,
            "2024-09-04T11:00:00.654321Z": 3.0
        }
    }

    # Create SeriesDataObject
    series_data_object = SeriesDataObject(
        data=data,
        start="2024-09-01",
        end="2024-09-05"
    )

    # Test that data is a DataFrame
    assert isinstance(series_data_object.data, pd.DataFrame)

    # Test the to_dataframe method
    df = series_data_object.to_dataframe()

    # Expected DataFrame
    expected_df = pd.DataFrame({
        "timestamp": pd.to_datetime([
            "2024-09-02T10:00:00.123456Z",
            "2024-09-02T11:00:00.123456Z",
            "2024-09-03T10:00:00.654321Z",
            "2024-09-04T11:00:00.654321Z"
        ]),
        "SERIES01": [0.0, None, 1.0, None],
        "SERIES02": [None, 2.0, None, 3.0]
    })

    # Ensure columns are in correct order
    df = df[['timestamp', 'SERIES01', 'SERIES02']]
    expected_df = expected_df[['timestamp', 'SERIES01', 'SERIES02']]

    # Sort and reset index
    df = df.sort_values('timestamp').reset_index(drop=True)
    expected_df = expected_df.sort_values('timestamp').reset_index(drop=True)

    # Check if the DataFrames are equal
    pd.testing.assert_frame_equal(df, expected_df, check_dtype=False)