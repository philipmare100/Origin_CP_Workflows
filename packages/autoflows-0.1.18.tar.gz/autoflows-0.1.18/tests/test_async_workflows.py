import json
import os
import time
from base64 import b64encode
from http import HTTPStatus
from io import BytesIO
from unittest import TestCase
from unittest.mock import patch
from uuid import uuid4

from requests import Response


SLEEP_TIME = 1


def mock_request_handler(url, *args, **kwargs) -> Response:
    resp = Response()

    resp.status_code = HTTPStatus.CREATED
    payload = kwargs["json"]
    payload["data"]["id"] = "1"
    resp.raw = BytesIO(json.dumps(payload).encode("utf-8"))

    time.sleep(SLEEP_TIME)

    return resp


class TestWorkflowThreading(TestCase):
    _client = None

    def setUp(self):
        with open(".env", "w") as f:
            dummy_jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
                         ".eyJuYW1lIjoiVGVzdCJ9."
                         "E7_2g0YuTeNMwAS55izHnYVg_gmPkaQq6efZVR_lQDk")
            f.writelines([
                f"API_ACCOUNT_ID={uuid4()}\n"
                f"API_TOKEN={dummy_jwt}\n"
                "API_BASE_URL=http://example.com\n"
            ])

        try:
            from coffee.client import JsonApiClient
            from coffee.schemas import api_schema_all

            self._client = JsonApiClient(
                schema=api_schema_all,
                auth=("username", "password"),
                verify_ssl=False,
                account_id="1"
            )
        except:
            os.remove(".env")
            raise

    def tearDown(self):
        self._client = None

        if os.path.exists(".env"):
            os.remove(".env")

    @patch("coffee.jsonapi_client.session.requests.request", mock_request_handler)
    @patch("coffee.utils.workflow_helpers.save_updated_csv", lambda *args, **kwargs: None)
    def test_series_workflow_threaded(self):
        from coffee.workflows import SeriesWorkflow
        from coffee.utils.workflow_helpers import CONCURRENT_REQUESTS

        workflow = SeriesWorkflow(client=self._client, upload_multithreaded=True)

        try:
            num_rows = 8
            with open("test.csv", "w") as test_csv:
                series_rows = [f"Name{i},Description{i}\n" for i in range(num_rows)]
                test_csv.writelines(["name,description\n"] + series_rows)

            start = time.time()
            workflow.bulk_create_series("test.csv")
            duration = time.time() - start

            # Since the request is set to sleep for 1 second, the threaded approach needs to take
            #  less time than 1 second * num_rows, otherwise threading and the max request limit isn't working
            assert duration < SLEEP_TIME * num_rows, duration

            # max 4 requests by default, so 8/4 = 2 batches
            num_upload_batches = num_rows / CONCURRENT_REQUESTS
            assert duration > num_upload_batches, duration
        finally:
            os.remove("test.csv")

    def test_threading_async_validation(self):
        """May not use threaded workflow with asyncio requests"""
        from coffee.workflows import SeriesWorkflow

        self._client.enable_async = True

        with self.assertRaises(ValueError):
            SeriesWorkflow(client=self._client, upload_multithreaded=True)
