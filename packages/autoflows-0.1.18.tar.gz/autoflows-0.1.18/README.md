# Automated Workflows (AutoFlows)

Welcome to the AutoFlows repository! This is your go-to repo for automated workflow scripts and Coffee - the WIRE SDK for Python - designed to streamline ops and project configuration workflows. The SDK and collection of scripts helps our Ops and Project Teams automate the usually manual and time-consuming tasks, enhancing productivity and efficiency.

## Overview

AutoFlows provides the coffee SDK and scripts that automate ops and project processes. These scripts are developed and maintained by the Data Team to support different clients and projects in automating their workflows, thus allowing them to focus more on design, analysis and less on repetitive tasks.

## Features

- **Coffee** - WIRE SDK for Python (Package)
- **Scripts** - Automated Workflow Scripts, either using coffee or classic versions (.py and .ipynb)

## Getting Started

To get started with AutoFlows:

1. **Clone the Repository**: Clone this repository to your local machine or development environment.
```git clone git@github.com:mmswire/autoflows.git```
2. **Install Dependencies**: Some scripts may require additional libraries or software. Ensure you read the script's documentation and install any necessary dependencies.

3. **Configure Scripts**: Before running a script, make sure to configure it as per your needs. This may include setting up environment variables, input data, etc.

4. **Run Scripts**: Execute the scripts according to the provided documentation. Ensure you have the necessary permissions and resources.

## Contribution Guidelines

Contributions and suggestions are encouraged! If you have improvements or new script or sdk ideas, please follow these steps:

- **Discuss**: Open an issue, in the Data Backlog on ClickUp, to discuss the proposed changes or new scripts.
- **Branch and Code**: Once agreed upon, create a new feature branch of the `dev` branch, make your changes, and write any necessary tests or documentation.
- **Pull Request**: Submit a pull request with a comprehensive description of changes.
