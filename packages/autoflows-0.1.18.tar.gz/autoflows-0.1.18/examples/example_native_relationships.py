import os

from coffee.jsonapi_client.common import ResourceTuple
from coffee.config import logger
from coffee.client import JsonApiClient
from coffee.resource_handlers import ConstantPropertyHandler, ComponentTypeHandler
from coffee.schemas import api_schema_all

api_base_url = os.environ.get('API_BASE_URL')


def example_main():
    with JsonApiClient(schema=api_schema_all) as client:
        logger.info(f'===== START WORKING ON: {api_base_url} =====')

        # target CP: DEMO_CP_01
        logger.info(f'===== FETCHING CP: DEMO_CP_01 =====')
        cp = ConstantPropertyHandler(client).get_by_name('DEMO_CP_01').resource

        # target CT: Bulk Trucks
        logger.info(f'===== FETCHING CT: Bulk Trucks =====')
        ct = ComponentTypeHandler(client).get_by_name('Bulk Trucks').resource

        # create CPCT (Method 1) =SUCCESS=
        logger.info(f'===== CREATING CPCT_1: Bulk Trucks-DEMO_CP_01 =====')
        cpct_1 = client.session.create('constant_property_component_type',
                                       constant_property_id=cp.id,
                                       component_type_id=ct.id,
                                       constant_property=ResourceTuple(cp.id, 'constant_property'),
                                       component_type=ResourceTuple(ct.id, 'component_type')
                                       )
        cpct_1.commit()

        # create CPCT (Method 2) =SUCCESS=
        logger.info(f'===== CREATING CPCT_2: Bulk Trucks-DEMO_CP_01 =====')
        relationships = {
            'constant_property': ResourceTuple(cp.id, 'constant_property'),
            'component_type': ResourceTuple(ct.id, 'component_type')
        }
        cpct_2 = client.session.create('constant_property_component_type')
        for rel_name, rel_data in relationships.items():
            setattr(cpct_2, rel_name, rel_data)
        cpct_2.commit()


if __name__ == '__main__':
    example_main()
