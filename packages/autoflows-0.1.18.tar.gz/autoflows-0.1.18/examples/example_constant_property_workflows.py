from coffee.client import JsonApiClient
from coffee.config import logger
from coffee.exceptions.database_exceptions import UniqueViolationError
from coffee.resource_handlers import ComponentTypeHandler, EventTypeHandler
from coffee.schemas import api_schema_all
from coffee.workflows import ConstantPropertyWorkflow


def example_single_create_constant_property_event_workflows():
    with JsonApiClient() as client:
        n = '02'
        cp_name = f'MAT_CP_{n}'
        cp_desc = f'Material CP {n}'
        et_name = 'MaterialEventType'

        # create cp
        cp_wf = ConstantPropertyWorkflow(client)
        # cp_wf.create_constant_property(cp_name, cp_desc, 'string')

        # create et
        et_wf = EventTypeHandler(client)
        attributes = {'name': et_name, 'base_type': 'event'}
        et = et_wf.create(attributes)
        et.commit()

        # link cp to et
        cp_wf.link_constant_property_to_event_type(cp_name, et_name)


def example_single_create_constant_property_component_workflows():
    with JsonApiClient() as client:
        n = '01'
        cp_name = f'MAT_CP_{n}'
        cp_desc = f'Material CP {n}'
        ct_name = 'MaterialComponentType'

        # create cp
        cp_wf = ConstantPropertyWorkflow(client)
        # cp_wf.create_constant_property(cp_name, cp_desc, 'string')

        # create ct
        # ct_wf = ComponentTypeHandler(client)
        # attributes = {'name': ct_name, 'base_type': 'resource'}
        # ct = ct_wf.create(attributes)
        # ct.commit()

        # link cp to ct
        cp_wf.link_constant_property_to_component_type(cp_name, ct_name)


def example_create_constant_property_workflows():
    with JsonApiClient(schema=api_schema_all) as client:
        cp_workflow = ConstantPropertyWorkflow(client)

        logger.info(f'========= Start Creating CP1 ===========')
        try:
            cp_workflow.create_constant_property(name='DEMO_CP_05',
                                                 description='Demo constant property number 5',
                                                 data_type='float',
                                                 aggregation='mean')
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= Start Creating CP2 (with calculation) ===========')
        try:
            cp_workflow.create_constant_property(name='DEMO_CP_06',
                                                 description='Demo constant property number 6',
                                                 data_type='float',
                                                 is_calculation=True,
                                                 aggregation='mean',
                                                 name_formula='[DEMO_CP_05]*100'
                                                 )
        except UniqueViolationError as e:
            logger.warning(e)

        ct_name = 'Bulk Trucks'
        logger.info(f'========= Start Linking CP1 to CT ===========')
        try:
            cp_workflow.link_constant_property_to_component_type('DEMO_CP_05', ct_name)
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= Start Linking CP2 to CT ===========')
        try:
            cp_workflow.link_constant_property_to_component_type('DEMO_CP_06', ct_name)
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= exampleing Complete ===========')


def example_patch_constant_property_workflows():
    with JsonApiClient(schema=api_schema_all) as client:
        cp_workflow = ConstantPropertyWorkflow(client)

        logger.info(f'========= Start Creating CP1 ===========')
        try:
            cp_workflow.create_constant_property(name='DEMO_CP_99',
                                                 description='Demo constant property number 99',
                                                 data_type='string',
                                                 aggregation='count')
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= Start Creating CP2 (with calculation) ===========')
        try:
            cp_workflow.create_constant_property(name='DEMO_CP_98',
                                                 description='Demo constant property number 98',
                                                 data_type='float',
                                                 is_calculation=True,
                                                 aggregation='mean',
                                                 name_formula='[DEMO_CP_05]*100'
                                                 )
        except UniqueViolationError as e:
            logger.warning(e)

        ct_name = 'Bulk Trucks'
        logger.info(f'========= Start Linking CP1 to CT ===========')
        try:
            cp_workflow.link_constant_property_to_component_type('DEMO_CP_99', ct_name)
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= Start Linking CP2 to CT ===========')
        try:
            cp_workflow.link_constant_property_to_component_type('DEMO_CP_98', ct_name)
        except UniqueViolationError as e:
            logger.warning(e)

        logger.info(f'========= Start Patching CP2 ===========')
        try:
            cp_workflow.patch_constant_property('DEMO_CP_98', name_formula='[DEMO_CP_05]*3000')
        except UniqueViolationError as e:
            logger.warning(e)
        logger.info(f'========= exampleing Complete ===========')


def example_bulk_create_constant_property_workflows():
    with JsonApiClient(schema=api_schema_all) as client:
        cp_workflow = ConstantPropertyWorkflow(client)
        cp_workflow.bulk_create_constant_property(
            csv_path='coffee/tests/data/test_constant_properties_data.csv'
        )
        cp_workflow.bulk_link_constant_property_to_component_type(
            csv_path='coffee/tests/data/test_constant_properties_data_cp_created_20240218_2229.csv'
        )


if __name__ == '__main__':
    example_single_create_constant_property_event_workflows()
