from coffee.client import JsonApiClient
from coffee.resource_handlers import ConstantPropertyHandler
from coffee.schemas import api_schema_all


def example_patch_constant_property():
    name="DEMO_CP03_DIM"
    name_formula="[DEMO_CP_04]*7"

    with JsonApiClient(schema=api_schema_all) as client:
        cp_handler = ConstantPropertyHandler(client)
        cp = cp_handler.get_by_name(name).resource
        cp.name_formula = name_formula
        cp.commit()
        assert True