from coffee.config import logger
from coffee.exceptions.database_exceptions import UniqueViolationError
from coffee.utils.helpers import post_request_error_parser


def example_post_request_error_parser():
    try:
        post_request_error_parser(response_json)
    except UniqueViolationError as e:
        logger.info('Success!')


if __name__ == '__main__':
    example_post_request_error_parser()

response_json = {'errors': [{'status': '500',
                             'source': {'pointer': '/data'},
                             'title': 'Unknown error',
                             'detail': 'Object creation error: (psycopg2.errors.UniqueViolation) duplicate key value '
                                       'violates unique constraint '
                                       '"uix_constant_property_name_account_id_key"\nDETAIL:  Key (name, '
                                       'account_id)=(DEMO_CP_05, d46a3f52-8282-403e-8142-1b1efe5b8c97) already '
                                       'exists.\n\n[SQL: INSERT INTO constant_property (created_on, changed_on, id, '
                                       'name, description, is_calculation, formula, aggregation, is_drop_down_list, '
                                       'data_type, file_type, calculation_type, time_series_conversion_method, '
                                       'weighted_by_id, positive_variance, created_by_fk, changed_by_fk, account_id, '
                                       'created_by_account_fk) VALUES (%(created_on)s, %(changed_on)s, %(id)s, '
                                       '%(name)s, %(description)s, %(is_calculation)s, %(formula)s, %(aggregation)s, '
                                       '%(is_drop_down_list)s, %(data_type)s, %(file_type)s, %(calculation_type)s, '
                                       '%(time_series_conversion_method)s, %(weighted_by_id)s, %(positive_variance)s, '
                                       '%(created_by_fk)s, %(changed_by_fk)s, %(account_id)s, '
                                       '%(created_by_account_fk)s)]\n[parameters: {\'created_on\': datetime.datetime('
                                       '2024, 2, 18, 14, 28, 47, 807131, tzinfo=tzutc()), \'changed_on\': '
                                       'datetime.datetime(2024, 2, 18, 14, 28, 47, 807137, tzinfo=tzutc()), '
                                       '\'id\': UUID(\'bfa3bde9-150b-46df-b49d-8a5beb948ac3\'), \'name\': '
                                       '\'DEMO_CP_05\', \'description\': \'Demo constant property number 5\', '
                                       '\'is_calculation\': False, \'formula\': None, \'aggregation\': \'mean\', '
                                       '\'is_drop_down_list\': False, \'data_type\': \'float\', \'file_type\': None, '
                                       '\'calculation_type\': \'basic\', \'time_series_conversion_method\': '
                                       '\'spread_from_start_to_end\', \'weighted_by_id\': None, '
                                       '\'positive_variance\': None, \'created_by_fk\': UUID('
                                       '\'2aa1a15f-4069-48af-b11f-41c5807d65c5\'), \'changed_by_fk\': UUID('
                                       '\'2aa1a15f-4069-48af-b11f-41c5807d65c5\'), \'account_id\': UUID('
                                       '\'d46a3f52-8282-403e-8142-1b1efe5b8c97\'), \'created_by_account_fk\': UUID('
                                       '\'d46a3f52-8282-403e-8142-1b1efe5b8c97\')}]\n(Background on this error at: '
                                       'https://sqlalche.me/e/14/gkpj)'}],
                 'jsonapi': {'version': '1.0'}}
