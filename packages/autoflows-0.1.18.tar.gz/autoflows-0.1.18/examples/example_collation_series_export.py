from coffee.client import JsonApiClient
from coffee.config import logger
from coffee.exceptions.database_exceptions import UniqueViolationError
from coffee.schemas import api_schema_all
from coffee.workflows.collation_workflows import ComponentCollationWorkflow


def example_create_and_delete_collation_series_export():
    s_name = 'DEMO_CP_01'
    cp_name = 'DEMO_CP_01'
    ct_name = 'Bulk Trucks'
    with JsonApiClient(schema=api_schema_all) as client:
        workflow = ComponentCollationWorkflow(client)

        # Create Collation
        try:
            workflow.create_collation_series_export(s_name, cp_name, ct_name)
        except UniqueViolationError as e:
            logger.error(f'UniqueConstraintViolationError: {e}')

        # Delete Collation
        workflow.delete_collation_series_export(s_name, cp_name, ct_name)


def example_bulk_create_and_delete_collation_series_export():
    csv_file_path = 'coffee/tests/data/test_bulk_collation_series_export_data.csv'
    with JsonApiClient(schema=api_schema_all) as client:
        component_collation_workflow = ComponentCollationWorkflow(client)

        # Bulk Create Collations
        component_collation_workflow.bulk_create_collation_series_export(csv_file_path)

        # Bulk Delete Collations
        component_collation_workflow.bulk_delete_collation_series_export(csv_file_path)


if __name__ == '__main__':
    example_bulk_create_and_delete_collation_series_export()
