from coffee.client import JsonApiClient
from coffee.config import logger
from coffee.resource_handlers import SeriesHandler
from coffee.schemas import api_schema_all
from coffee.workflows.series_workflows import SeriesWorkflow


def example_get_series():
    with JsonApiClient(schema=api_schema_all) as client:
        s_handler = SeriesHandler(client)
        series = s_handler.get_by_name('TestSeries01').resource
        logger.debug(f'series: {series}')


def example_create_series():
    with JsonApiClient(schema=api_schema_all) as client:
        series_workflow = SeriesWorkflow(client)
        s = series_workflow.create_series('MAT_SERIES_01')
        logger.debug(f'series: {s}')


def example_bulk_create_series():
    with JsonApiClient(schema=api_schema_all) as client:
        series_workflow = SeriesWorkflow(client)
        series_workflow.bulk_create_series(
            csv_path='coffee/tests/data/test_series_data.csv'
        )


if __name__ == '__main__':
    example_create_series()
