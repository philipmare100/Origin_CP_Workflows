import json
import os
import logging

from coffee.client import JsonApiClient
from coffee.jsonapi_client.filter import Filter, Inclusion, Modifier
from coffee.schemas import api_schema_all
from coffee.resource_handlers import ConstantPropertyHandler, ComponentTypeHandler, ConstantPropertyComponentTypeHandler

# auth = ('arbitrary', os.environ.get('API_TOKEN'))
# client = JsonApiClient(os.environ.get('API_BASE_URL'), enable_async=False, schema=None, auth=auth)

if __name__ == '__main__':
    with JsonApiClient() as client:
        # === CT ===
        # ct_handler = ComponentTypeHandler(client)
        # ct = ct_handler.get(
        #     filter_obj=Filter(name='Bulk Trucks')
        # )
        # print(f'ct.resource.name={ct.resource.name}')

        # === CP ===
        cp_handler = ConstantPropertyHandler(client)
        # cp_new = cp_handler.create({
        #     'name': 'New_CP_11',
        #     'description': 'Description of the new cp 11',
        #     'data_type': 'float'
        # })
        cp = cp_handler.get(filter_obj=Filter(name="New_CP_11"))
        print(f'cp.resource.name={cp.resource.name}')

        # === CPCT ===
        # cpct_handler = ConstantPropertyComponentTypeHandler(client)
        # new_cpct_attr = {
        #     'component_type_id': ct.resource.id,
        #     'constant_property_id': cp.resource.id,
        # }
        # new_cpct_rel = {
        #     'component_type': ct.resource,
        #     'constant_property': cp.resource,
        # }

        # cpct = client.session.create('constant_property_component_type',
        #                              component_type=[ct.resource.id],
        #                              constant_property=[cp.resource.id],
        # )
        # cpct.component_type = ct.resource
        # cpct.constant_property = cp.resource
        # cpct.commit()

        # cpct_doc = cpct_handler.create(attributes=new_cpct_attr)  # ToDo: Create, with Try Except
        # cpct_id = cpct_doc.resource.id
        # print(f"Created new CPCT with ID: {cpct_id}")
