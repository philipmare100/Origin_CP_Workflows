from coffee.client import JsonApiClient
from coffee.config import logger
from coffee.resource_handlers import (
    EngineeringUnitHandler,
    SeriesHandler,
    SeriesTypeHandler,
    ProcessComponentHandler,
    SeriesComponentHandler
)
from coffee.schemas import api_schema_all


def example_unit_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        unit_handler = EngineeringUnitHandler(client)

        # Get all units on instance
        units = unit_handler.get().resources
        logger.debug(f'num of units: {len(units)}')
        assert True

        # Get tonnes unit
        unit_t = unit_handler.get_by_name('t').resource
        logger.debug(f'unit_t: {unit_t}')
        assert True


def example_series_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        s_handler = SeriesHandler(client)

        series = s_handler.get_by_name('TestSeries01').resource
        logger.debug(f'series: {series}')
        assert True

        calc = s_handler.get_by_name('MPD_TEST_S_3').resource
        logger.debug(f'calc: {calc}')
        assert True


def example_series_type_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        s_handler = SeriesTypeHandler(client)

        series_types = s_handler.get().resources
        logger.debug(f'num of series types: {len(series_types)}')
        assert True


def example_process_component_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        process_handler = ProcessComponentHandler(client)

        process = process_handler.get_by_name('Test work').resource
        logger.debug(f'process: {process}')
        assert True


def example_link_series_to_process_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        s_handler = SeriesHandler(client)
        series = s_handler.get_by_name('TestSeries01').resource
        logger.debug(f'series: {series}')

        process_handler = ProcessComponentHandler(client)
        process = process_handler.get_by_name('Test work').resource
        logger.debug(f'process: {process}')


def example_assert_link_series_to_process_handler():
    with JsonApiClient(schema=api_schema_all) as client:
        sc_handler = SeriesComponentHandler(client)
        sc = sc_handler.get_by_linked_series_and_component_names(
            'TestSeries01', 'Test work').resource
        logger.debug(f'sc: {sc}')
        assert True


if __name__ == '__main__':
    example_assert_link_series_to_process_handler()
